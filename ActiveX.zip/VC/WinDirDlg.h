// WinDirDlg.h : header file
//

#if !defined(AFX_WINDIRDLG_H__31E2D284_5FCF_4FDB_B4F2_77E85A241101__INCLUDED_)
#define AFX_WINDIRDLG_H__31E2D284_5FCF_4FDB_B4F2_77E85A241101__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

/////////////////////////////////////////////////////////////////////////////
// CWinDirDlg dialog

class CWinDirDlg : public CDialog
{
// Construction
public:
	CWinDirDlg(CWnd* pParent = NULL);	// standard constructor

// Dialog Data
	//{{AFX_DATA(CWinDirDlg)
	enum { IDD = IDD_WINDIR_DIALOG };
	CString	m_Edit;
	//}}AFX_DATA

	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CWinDirDlg)
	protected:
	virtual void DoDataExchange(CDataExchange* pDX);	// DDX/DDV support
	//}}AFX_VIRTUAL

// Implementation
protected:
	HICON m_hIcon;

	// Generated message map functions
	//{{AFX_MSG(CWinDirDlg)
	virtual BOOL OnInitDialog();
	afx_msg void OnPaint();
	afx_msg HCURSOR OnQueryDragIcon();
	afx_msg void OnButton1();
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
};

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_WINDIRDLG_H__31E2D284_5FCF_4FDB_B4F2_77E85A241101__INCLUDED_)
